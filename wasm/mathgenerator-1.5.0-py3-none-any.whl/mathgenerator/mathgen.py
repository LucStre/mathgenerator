# Present for backwards compatibility < 1.4.0
# Enables using `from mathgenerator import mathgen`
from .__init__ import *
